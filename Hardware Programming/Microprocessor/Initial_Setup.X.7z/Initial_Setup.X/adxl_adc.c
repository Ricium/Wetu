#include "adxl_adc.h"
#include <xc.h>

void SetupADC(void)
{
    AD1PCFG = 0xFF7C;          // Only AN0, AN1 and AN4 as analog inputs
    AD1CON1 = 0x00E0;          // Internal counter triggers conversion    
    AD1CON3 = 0x0F00;          // Sample time = 15Tad, Tad = Tcy
    AD1CON2 = 0x003C;          // Set AD1IF after every 16 samples
}

int SampleADC(int channel)
{
    AD1CHS = channel;          // Connect channel as positive input AD1CSSL = channel;
    int ADCValue, count; 
    int * ADC16Ptr ;
    
    AD1CON1bits.ADON = 1;                   // Turn ON ADC
    
    ADCValue = 0;                           // Clear Register
    ADC16Ptr = (int*)&ADC1BUF0;             // Initialize ADC1BUF Pointer
    IFS0bits.AD1IF = 0;                     // Clear ADC Interrupt Flag
    AD1CON1bits.ASAM = 1;                   // Auto Start Sampling 
    
    while (!IFS0bits.AD1IF){};              // Wait for Sample/Conversion to Finish
    AD1CON1bits.ASAM = 0;                   // Stop Sample/Conversion 
    for (count = 0; count < 16; count++)    // Average 16 Word ADC value
    {
        ADCValue = ADCValue + *ADC16Ptr++;
    }
        
    ADCValue = ADCValue >> 4;               // Justify Result
    
    return ADCValue;                        // Return ADC Value
}
