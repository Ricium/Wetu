#include <timer.h>
#include "configbits.h"
#include "wifi_uart.h"
#include "xbee_uart.h"
#include "adxl_adc.h"
#include "string_functions.h"

#define GetInstructionClock()  (8000000)
#define MAXBUF                  250
#define BAUDRATE9600            25
#define BAUDRATE19200           12

//const char* DEVICEID = "START:AA00AA\r\n"; // Device Identifier
char databuf[MAXBUF];       // Buffer to store data from WiFi polling
int bufcount = -1;          // Buffer counter

void __attribute__((interrupt, no_auto_psv, shadow)) _U1RXInterrupt(void) {
   /*The interrupt is called when data is received on the WiFi UART*/
    char temp = U1RXREG;
    
   if(bufcount >= MAXBUF-1)       // Check if buffer is full
   {
       // Reset Interrupt Flag      
       IFS0bits.U1RXIF = 0;
       return;
   }
   else
   {
        // Save data in buffer
        bufcount++;   
        databuf[bufcount] = temp;
        //SendcXBee(U1RXREG);
     
        // Reset Interrupt Flag
        IFS0bits.U1RXIF = 0;
   }   
}

void __attribute__((interrupt, no_auto_psv, shadow)) _U2RXInterrupt(void) {
    /*The interrupt is called when data is received on the XBee UART*/  
    // Send data to WiFi UART
    SendcWiFi(U2RXREG);
   
    //reset interrupt
    IFS1bits.U2RXIF = 0;
}

int main(void)
{
    SetupWiFi(BAUDRATE9600);
    SetupXBee(BAUDRATE19200);
    
    //clear_data_buffer(databuf, &bufcount, DEVICEID);
    clear_data_buffer(databuf, &bufcount);
    
    SendXBee("Waiting...\r\n");
    WaitXBee();
    SendXBee("Polling...\r\n");
    PollProximity();
    
    while(1)
    {       
        if(bufcount >= MAXBUF-1)
        {     
            DisableWiFi();
            databuf[MAXBUF-1] = 0x7E;
            SendXBee(databuf);
            WaitXBee();
            DelayMs(2500);
            
            //clear_data_buffer(databuf, &bufcount, DEVICEID);
            clear_data_buffer(databuf, &bufcount);
            
            EnableWiFi(); 
            PollProximity();
        }
    };
}


