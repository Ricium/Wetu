/* 
 * File:   adc.h
 * Author: User
 *
 * Created on 21 July 2015, 9:59 AM
 */

#ifndef ADC_H
#define	ADC_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void SetupADC(void);


#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */

