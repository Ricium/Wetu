/* 
 * File:   string_functions.h
 * Author: RM Lombard
 *
 * Created on 03 August 2015, 11:09 AM
 */

#ifndef STRING_FUNCTIONS_H
#define	STRING_FUNCTIONS_H

//extern void clear_data_buffer(char * buffer, int * counter, const char * deviceid);
extern void clear_data_buffer(char * buffer, int * counter);

#endif	/* STRING_FUNCTIONS_H */

