#ifndef ADXL_ADC_H
#define	ADXL_ADC_H

extern void SetupADC(void);

extern int SampleADC(int channel);

#endif	/* ADXL_ADC_H */

