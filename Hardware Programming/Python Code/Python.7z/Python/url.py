import urllib
import urllib2

url = 'http://localhost/project/poster.php'
values = {'data' : 'Michael Foord'}

data = urllib.urlencode(values)
req = urllib2.Request(url, data)
response = urllib2.urlopen(req)
the_page = response.read()
