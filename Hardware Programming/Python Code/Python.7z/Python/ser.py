import serial
import thread

print("Starting")
ser = serial.Serial('COM4',19200)
print("Connected to: " + ser.portstr)

line = []
count = 0

def senddata(data, filename):
    f = open(filename,'a')
    f.write(joined_seq)
    f.close()

while True:
    for c in ser.read():
        line.append(c)
        joined_seq = ''.join(str(v) for v in line)
        
        if c == '~':
            count = count + 1
            
            try:
                thread.start_new_thread(senddata, (joined_seq, "Line " + str(count) + '.txt'))
            except:
                print "Error: unable to start thread"
                
            print("Line: " + joined_seq)
            line = []
            f = open('Test.txt','a')
            f.write(joined_seq)
            f.close()
            break
            
ser.close()
