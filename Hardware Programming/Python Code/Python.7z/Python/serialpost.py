import serial
import threading
import urllib
import urllib2

print("Starting")
ser = serial.Serial('COM4',19200)
print("Connected to: " + ser.portstr)

line = []

def postdata(dat):
    url = 'http://127.0.0.1/project/poster.php'
    values = {'data' : dat}

    data = urllib.urlencode(values)
    req = urllib2.Request(url, data)
    response = urllib2.urlopen(req)
    the_page = response.read()

while True:
    for c in ser.read():
        line.append(c)
        joined_seq = ''.join(str(v) for v in line)
        
        if c == '~':
            t = threading.Thread(target=postdata, args=(joined_seq,))
            t.start()            
            
            print("Line: " + joined_seq)
            line = []

            f = open('Test.txt','a')
            f.write(joined_seq)
            f.close()
            break
            
ser.close()
