/* 
 * File:   main.c
 * Author: RM
 *
 * Created on 16 June 2015, 2:27 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include "configbits.h"
#include <uart.h>

char data[10];
char items[100][5];
int count = -1;
int itemcount = -1;

void __attribute__((interrupt, no_auto_psv, shadow)) _U1RXInterrupt(void) {
   char Temp;
   count++;
   int i;
   
   if(count == 10)
   {
       count = 0;
   }
   
   if(U1STAbits.OERR == 1)
   {
       U1STAbits.OERR = 0;
   }

   Temp = U1RXREG;
   data[count] = Temp; 
   
   if(Temp == 'a')
   {
       itemcount++;
       for(i = 0; i < 5; i++)
       {
           items[itemcount][i] = data[i];
       }
       for(i = 0; i <= count; i++)
       {
           data[i] = '\0';
       }
       count = -1;
   }
   

   //reset interrupt
   IFS0bits.U1RXIF = 0;
}

int main(int argc, char** argv) {

    data[0] = '\0';
    int i;
    for(i=0;i<10;i++)
    {
        items[i][0] = '\0';
    }
    
    AD1PCFG = 0xFF7F;
   
    TRISBbits.TRISB2 = 1;
    TRISBbits.TRISB7 = 0;
    
    U1MODE = 0;
    U1STA = 0;
    U1BRG = 12;
      
    
    IEC0bits.U1RXIE = 1;
    
    U1MODEbits.UARTEN = 1;
    U1STAbits.UTXEN = 1;
    
    putsUART1("\r\nTest\r\n");
        
    while(1) 
    {       
        if(itemcount == 2)
        {
            putcUART1("Vol");
            return 0;
        }
    };
    
    return (EXIT_SUCCESS);
}



