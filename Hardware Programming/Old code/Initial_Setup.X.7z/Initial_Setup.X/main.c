#include <stdio.h>
#include <stdlib.h>
#include "configbits.h"
#include "wifi_uart.h"
#include "xbee_uart.h"
#include "adxl_adc.h"

char databuf[345];
int bufcount = -1;
char data[10][6];

void clear_data_buffer(void)
{
    int loop;
    
    for(loop = 0; loop <= bufcount; loop++)
    {
        databuf[loop] = '\0';
    }
    
    bufcount = -1;
}

int find(char item, char * text, int from, int to)
{
    int index;
    for(index = from; index <= to; index++)
    {
        if(text[index] == item)
        {
           return index; 
        }
    }
    
    return -1;
}

void set_data(void)
{
    int loop;
    int loop2;
    int start = 0;
    
    for(loop = 0; loop < 6; loop++)
    {
        start = find('"', databuf, 22+(45*loop), 45);
        for(loop2 = start; loop2 < start+6; loop2++)
        {
            if(databuf[loop2] != '\0')
                data[loop][loop2-start] = databuf[loop2]; 
        }
    }
}


int main(void)
{
    SetupWiFi(25);
    SetupXBee(12);
    clear_data_buffer();

    int loop;
     
    while(1)
    {
        if(bufcount == 344)
        {
            set_data();
            
            //SendXBee(databuf);
            for(loop = 0; loop < 6; loop++)
            {
                SendXBee(data[loop]);
            }
            
            clear_data_buffer();
        }
    };
}

/*Interrupts*/
void __attribute__((interrupt, no_auto_psv, shadow)) _U1RXInterrupt(void) {
   char Temp;

   Temp = U1RXREG;
   
   bufcount++;   
   databuf[bufcount] = Temp;
     
   //reset interrupt
   IFS0bits.U1RXIF = 0;
}

void __attribute__((interrupt, no_auto_psv, shadow)) _U2RXInterrupt(void) {
   char Temp;

   Temp = U2RXREG;
   SendcWiFi(Temp);
   
   //reset interrupt
   IFS1bits.U2RXIF = 0;
}
