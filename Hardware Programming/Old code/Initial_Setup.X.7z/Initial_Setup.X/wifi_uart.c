#include "wifi_uart.h"
#include <xc.h>
#include <uart.h>

void SetupWiFi(int BAUDRATE){
    AD1PCFG = 0xFF7C;           // Only AN0, AN1 and AN4 as analog inputs
    TRISBbits.TRISB2 = 1;       //RX input
    TRISBbits.TRISB7 = 0;       //TX output
    
    U1MODE = 0;
    U1STA = 0;    
    U1BRG = BAUDRATE;           // Set Baud Rate    
       
    IEC0bits.U1RXIE = 1;        // enable rx interrupt
   
    U1MODEbits.UARTEN = 1;      // enable uart
    U1STAbits.UTXEN = 1;        // enabale tx  
}

extern void SendWiFi(char * TEXT){
    putsUART1(TEXT);
}

extern void SendcWiFi(char TEXT){
    putcUART1(TEXT);
}
